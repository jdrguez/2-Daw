const ring = document.querySelector('#ring')
ring.addEventListener('click', () =>{
    document.querySelector('.chosen').style.backgroundColor='yellow'
})