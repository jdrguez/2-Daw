const bats = document.querySelector('#batS');
        bats.addEventListener('click', () => {
            document.body.style.backgroundImage = 'url("https://www.shutterstock.com/image-vector/chattogram-bangladesh-june-17-2023-600nw-2318874201.jpg")';
        });