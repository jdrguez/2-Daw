const escudo = document.querySelector('#escudo');
        escudo.addEventListener('click', () => {
            escudo.style.left = '100px'
        });