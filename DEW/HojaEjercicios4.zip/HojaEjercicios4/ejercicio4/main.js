document.querySelector('#mordor').addEventListener('click', () => {
    alert('Has llegado a Mordor, Felicidades!!');
});

document.querySelector('#rohan').addEventListener('click', () => {
    alert('Has llegado a Rohan, Felicidades');
});

document.querySelector('#gondor').addEventListener('click', () => {
    alert('Has llegado a Gondor, Felicidades');
});

