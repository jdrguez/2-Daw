document.querySelector('#groot').addEventListener('click', () => {
    alert('¡Yo soy Groot!');
});