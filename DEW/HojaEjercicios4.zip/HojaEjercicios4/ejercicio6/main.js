const sable = document.querySelector('#sableLaser');
        sable.addEventListener('click', () => {
            sable.src = 'https://www.aceroymagia.com/Images/articulo/sable-de-luz-obi-wan-hoja-extraible/01-sable-de-luz-obi-wan-hoja-extraible.jpg'; 
});